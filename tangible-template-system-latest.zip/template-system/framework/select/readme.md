# Select

## Current

- [x] Fork Select2 since upstream development has stalled: https://github.com/select2/select2
  
- Resolve jQuery Migrate warnings
  - jQuery.isArray is deprecated; use Array.isArray
  - jQuery.trim is deprecated; use String.prototype.trim

