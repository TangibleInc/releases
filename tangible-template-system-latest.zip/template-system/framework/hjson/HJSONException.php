<?php
namespace tangible\hjson;

class HJSONException extends \Exception {}
