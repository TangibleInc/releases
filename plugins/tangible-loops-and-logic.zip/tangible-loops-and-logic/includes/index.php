<?php

if (is_admin()) {
  require_once __DIR__.'/admin/index.php';
}
