<?php

namespace Tangible\HTML\Parser;

/**
 * Emit when the parser has an error.
 */
class ParseError extends \Exception
{
}
