// Alias require('jquery') in node_modules/select2
module.exports = window.jQuery
