<?php
/**
 * Logging methods: see, trace, log, log_to_file
 */

require_once __DIR__.'/file.php';
require_once __DIR__.'/format.php';
require_once __DIR__.'/log.php';
require_once __DIR__.'/see.php';
require_once __DIR__.'/trace.php';
