# Log

Logging utilities

```sh
tangible\see($anything);
tangible\log($anything);
```
