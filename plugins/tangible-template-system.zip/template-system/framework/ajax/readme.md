# AJAX

Server side (PHP):

```php
use tangible\ajax;

ajax\enqueue();
```

Browser side (JS):

```js
const { ajax } = window.Tangible
```
