import * as Preact from 'preact/compat'

window.Tangible = window.Tangible || {}
window.Tangible.Preact = Preact
